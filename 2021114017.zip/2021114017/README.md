# DASS Assignment 1, Part A

- Ayan Datta (2021114017)

[Link To Deployed Website](https://deluxe-pastelito-95680f.netlify.app/)

## Setting up development build

Run the following commands to setup the development environment.

```shell
cd frontend
```

```shell
yarn
```

## Running a local development server

```shell
yarn dev
```
